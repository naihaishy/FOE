INSERT INTO `tp_news_category` VALUES (1, '直播', 'live', '', 0, 0, 0);
INSERT INTO `tp_news_category` VALUES (2, '系统', 'system', '', 0, 4, 0);
INSERT INTO `tp_news_category` VALUES (3, '课程', 'course', '', 0, 0, 0);
INSERT INTO `tp_news_category` VALUES (4, '论坛', 'forum', '', 0, 0, 0);
