INSERT INTO `tp_course_category` VALUES (1, '软件开发', 'softwaredev', 0, '', 5);
INSERT INTO `tp_course_category` VALUES (2, '电子类', 'electrocity', 0, '', 2);
INSERT INTO `tp_course_category` VALUES (3, '数学物理类', 'mathphy', 0, '', 1);
INSERT INTO `tp_course_category` VALUES (4, '文学类', 'literature', 0, '', 1);
INSERT INTO `tp_course_category` VALUES (5, '计算机类', 'computer', 0, '', 5);
