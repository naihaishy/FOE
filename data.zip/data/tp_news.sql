INSERT INTO `tp_news` VALUES (1, 'FOE系统关闭', 2, 'FOE系统将于2017年6月20日关闭，届时将无法访问。', '4', NULL, 'publish', 1493374227, 0, 0);
INSERT INTO `tp_news` VALUES (2, 'FOE系统将进行维护', 2, '<p>FOE系统将进行维护<img alt=\"\" src=\"/Public/Upload/Common/news/2017-05-09/jlwutb_Panda_Kungfu_128px_556429_easyicon.net.png\" style=\"height:128px; width:128px\" /></p>\r\n\r\n<p>dd</p>\r\n', '5', 0, 'publish', 1494345555, 1494413169, 0);
INSERT INTO `tp_news` VALUES (3, '2017年FOE实现盈利100亿', 2, '<p>呵呵了</p>\r\n', '5', 0, 'publish', 1494413671, 1494413671, 0);
INSERT INTO `tp_news` VALUES (5, 'FOE可以通过QQ登录', 2, '<p>本系统可以通过QQ登录进行学员登录了。</p>\r\n', '5', 0, 'publish', 1496130491, 1496130491, 0);
