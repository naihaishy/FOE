INSERT INTO `tp_manual_category` VALUES (1, '直播类', 'live', '', 0, 2, 899);
INSERT INTO `tp_manual_category` VALUES (2, '课程类', 'course', '', 0, 1, 450);
INSERT INTO `tp_manual_category` VALUES (4, 'OJ类', 'oj', 'online judge', 0, 2, 800);
