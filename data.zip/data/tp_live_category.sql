INSERT INTO `tp_live_category` VALUES (1, '计算机类', 'computer', '', 4);
INSERT INTO `tp_live_category` VALUES (2, '人文类', 'art', '', 0);
