INSERT INTO `tp_auth_group_access` VALUES (1, 1);
INSERT INTO `tp_auth_group_access` VALUES (2, 0);
INSERT INTO `tp_auth_group_access` VALUES (3, 3);
INSERT INTO `tp_auth_group_access` VALUES (4, 2);
INSERT INTO `tp_auth_group_access` VALUES (5, 1);
INSERT INTO `tp_auth_group_access` VALUES (10, 3);
