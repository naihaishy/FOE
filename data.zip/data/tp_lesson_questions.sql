INSERT INTO `tp_lesson_questions` VALUES (8, 25, ' 预处理命令行必须位于C源程序的起始位置吗？', 32, '', 1491320505, 0, 0, 0, 1, 0);
INSERT INTO `tp_lesson_questions` VALUES (9, 25, 'typedef干啥用的', 32, '', 1491357061, 0, 0, 1, 1, 0);
INSERT INTO `tp_lesson_questions` VALUES (16, 25, '为什么C开头要加<stdio.h>', 32, '&lt;p&gt;&lt;strong&gt;sdsdssjgffgg&lt;/strong&gt;&lt;/p&gt;', 1491551187, 0, 0, 0, 0, 0);
INSERT INTO `tp_lesson_questions` VALUES (18, 5, '怎么样学习C语言？', 33, '&lt;p&gt;怎样学习C语言&lt;/p&gt;', 1492155404, 0, 0, 0, 1, 0);
INSERT INTO `tp_lesson_questions` VALUES (21, 27, '爬虫是什么', 32, '&lt;p&gt;爬虫是什么&lt;/p&gt;', 1493963208, 1493963208, 0, 0, 0, 0);
INSERT INTO `tp_lesson_questions` VALUES (22, 27, ' 怎么学爬虫', 32, '&lt;p&gt;&amp;nbsp;怎么学爬虫&lt;/p&gt;', 1493963487, 1493963487, 0, 0, 0, 0);
INSERT INTO `tp_lesson_questions` VALUES (23, 27, 'test', 32, '&lt;p&gt;&amp;nbsp;怎么学爬虫&lt;/p&gt;', 1493963551, 1493963551, 0, 0, 0, 0);
INSERT INTO `tp_lesson_questions` VALUES (24, 28, 'Scrapy爬虫框架', 32, '&lt;p&gt;Scrapy爬虫框架如何使用&lt;/p&gt;', 1493963675, 1493963675, 0, 0, 1, 0);
