INSERT INTO `tp_live_room` VALUES (4154145, 4, 'normal', 0, 'rtmp://fms.zhfsky.com/live');
INSERT INTO `tp_live_room` VALUES (6595547, 6, 'normal', 0, 'rtmp://fms.zhfsky.com/live/');
