INSERT INTO `tp_teacher_forum` VALUES (1, '课程', '', '课程管理 包括增删改查', 0, 'general', '', 'open');
INSERT INTO `tp_teacher_forum` VALUES (2, '直播', '', '有关直播的问题可在此版块下发帖咨询', 0, 'general', '', 'open');
INSERT INTO `tp_teacher_forum` VALUES (3, '课时', '', '', 1, 'other', '', 'open');
INSERT INTO `tp_teacher_forum` VALUES (4, '课程文件', '', '', 1, 'general', '', 'open');
INSERT INTO `tp_teacher_forum` VALUES (5, 'OBS', '', 'OBS直播软件使用咨询', 2, 'general', '', 'open');
INSERT INTO `tp_teacher_forum` VALUES (6, 'RTMP', '', 'RTMP相关问题可在此处咨询', 2, 'general', 'rtmp', 'open');
