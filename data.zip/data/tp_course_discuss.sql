INSERT INTO `tp_course_discuss` VALUES (1, 12, 32, 3, '大家认为C语言到底有什么用', '大家认为C语言到底有什么用', 0);
INSERT INTO `tp_course_discuss` VALUES (2, 12, 33, 3, '大家在哪', '家', 0);
