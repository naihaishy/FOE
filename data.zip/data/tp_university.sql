INSERT INTO `tp_university` VALUES (1, '清华大学', '', '', 'https://storagecdn.xuetangx.com/public_assets/xuetangx/partner/tsh.png');
INSERT INTO `tp_university` VALUES (2, '复旦大学', '', '', 'https://storagecdn.xuetangx.com/public_assets/xuetangx/partner/FDU.png');
INSERT INTO `tp_university` VALUES (3, '南京大学', '', '', 'https://storagecdn.xuetangx.com/public_assets/xuetangx/partner/NJU.png');
