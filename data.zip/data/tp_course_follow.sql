INSERT INTO `tp_course_follow` VALUES (35, 41);
INSERT INTO `tp_course_follow` VALUES (34, 16);
INSERT INTO `tp_course_follow` VALUES (34, 41);
INSERT INTO `tp_course_follow` VALUES (32, 12);
INSERT INTO `tp_course_follow` VALUES (36, 14);
INSERT INTO `tp_course_follow` VALUES (32, 16);
