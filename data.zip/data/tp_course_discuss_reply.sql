INSERT INTO `tp_course_discuss_reply` VALUES (1, 2, 32, 3, '加了', 0, 0);
