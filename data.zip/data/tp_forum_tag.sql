INSERT INTO `tp_forum_tag` VALUES (1, 'PHP', 1);
